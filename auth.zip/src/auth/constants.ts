export default {
  jwtSecret: 'mysupersecret'
}